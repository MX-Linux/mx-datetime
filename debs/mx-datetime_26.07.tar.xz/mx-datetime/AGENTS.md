# Agent Guidelines for mx-datetime

## Build Commands
- **Build**: `./build.sh` (CMake with Ninja build system)
- **Build with Clang**: `./build.sh --clang`
- **Debug build**: `./build.sh --debug`
- **Debug with Clang**: `./build.sh --debug --clang`
- **Clean build**: `./build.sh --clean`
- **Debian package**: `./build.sh --debian`
- **Manual CMake**: `cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build --parallel`
- **Clean**: `rm -rf build`

## Code Style
- **Language**: C++ with Qt6 framework
- **Headers**: Apache 2.0 license header block required in all new files
- **Includes**: Qt includes first, then local headers (e.g., `#include "datetime.h"`)
- **Naming**: PascalCase for classes (MXDateTime), camelCase for methods/variables
- **Braces**: Opening brace on same line for functions/classes
- **Indentation**: 4 spaces, no tabs
- **String literals**: Use Qt string literals (`u"text"_s`) for Qt6 compatibility
- **Qt version**: Target Qt6 with `QT_DISABLE_DEPRECATED_UP_TO=0x060400`
- **Memory**: Use Qt smart pointers and RAII patterns
- **Error handling**: Use QMessageBox for user-facing errors, qDebug() for debugging

## File Structure
- Header files (.h) contain class declarations with proper include guards
- Implementation files (.cpp) contain method implementations
- UI files (.ui) for Qt Designer forms
- Resource files (.qrc) for embedded assets
- Translation files in translations/ directory (.ts files)