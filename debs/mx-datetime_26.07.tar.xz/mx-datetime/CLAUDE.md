# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

mx-datetime is a Qt6-based GUI application for configuring date, time, and timezone settings on MX Linux. It provides a user-friendly interface for managing system time, hardware clock, timezones, and NTP server configuration.

## Build System

The project uses CMake with Ninja as the build system. Build configuration is managed through CMake presets defined in `CMakePresets.json`.

### Build Commands

**Primary build script:** `./build.sh [command] [options]`
- `./build.sh all` - Configure and build (default)
- `./build.sh fresh` - Clean first, then configure and build
- `./build.sh configure` - Configure only
- `./build.sh make` - Build only
- `./build.sh make-clean` - Clean build artifacts only
- `./build.sh clean` - Ultimate clean (removes _build_ directory)
- `./build.sh --arch` - Build Arch Linux package (outputs to `build/*.pkg.tar.zst`)

**Direct CMake workflow commands:**
- `cmake --workflow --preset default` - Configure and build
- `cmake --workflow --preset default --fresh` - Fresh build
- `cmake --preset default` - Configure only
- `cmake --build --preset default` - Build only

**Alternative compiler presets:**
- `cmake --workflow --preset clang` - Build with Clang
- `cmake --workflow --preset gcc` - Build with GCC
- `cmake --workflow --preset clazy` - Static analysis with Clazy

**Build output:** `_build_/Release/mx-datetime` (or `_build_/Debug/mx-datetime` for debug builds)

**Running the application:**
- Run directly: `./_build_/Release/mx-datetime`
- Run with elevated privileges (to test system changes): `pkexec ./_build_/Release/mx-datetime`
- The application can run as normal user - it will elevate privileges only when needed for system changes

### Build Configuration

Custom build logic is in `build.cmake`:
- Enforces out-of-source builds (fails if build in source directory)
- Enables `compile_commands.json` export for IDE integration
- Configures compiler diagnostics with color output
- Handles version extraction from `debian/changelog` via `dpkg-parsechangelog`
- Manages Qt translation file compilation (`.ts` → `.qm`)
- Sets up LTO (Link Time Optimization) for release builds
- Default install prefix is `/usr`

## Architecture

### Core Components

**Main Dialog (MXDateTime class)** - `datetime.{h,cpp}`, `datetime.ui`
- Central application controller managing all functionality
- Implements tabbed interface with lazy loading (tabs loaded on first access)
- Detects init system (SystemV, OpenRC, or SystemD) to use appropriate system commands
- Uses privileged execution for system changes (via `pkexec` or `su-to-root`)
- Tracks changes separately for date, time, and timezone to minimize system updates

**Custom Widgets:**
- `MTimeEdit` (datetime.h:32-41) - QTimeEdit subclass preventing cursor jumping during live updates
- `ClockFace` (clockface.{h,cpp}) - Custom analog clock widget with QPainter rendering

**About Dialog** - `about.{h,cpp}`
- Standard about dialog for application information

### Key Architectural Patterns

**Privilege Escalation:**
The application runs as normal user but elevates privileges for system changes via:
- `execute()` / `shell()` methods with `elevate=true` parameter (datetime.cpp:158-196)
- Uses `pkexec` (preferred) or falls back to `gksu` if pkexec not available
- Commands are proxied through `/usr/lib/mx-datetime/helper` script which uses `eval` to execute the command
- Polkit policy file: `scripts/org.mxlinux.pkexec.mx-datetime-helper.policy`
- Commands executed via QProcess with proper error handling and debug logging

**Init System Abstraction:**
The `sysInit` enum (SystemV, OpenRC, SystemD) determines which commands to use:
- Detected in `startup()` (datetime.cpp:87-99) by checking:
  1. `/run/openrc` existence → OpenRC
  2. `/proc/1/comm` contains "systemd" → SystemD
  3. Otherwise → SystemV (default)
- Different command sequences for enabling/disabling NTP services
- Hardware clock operations vary by init system

**Change Tracking:**
Separate delta tracking for user modifications:
- `dateDelta`, `timeDelta`, `zoneDelta` - track changes from system state
- `changedServers` - tracks NTP server list modifications
- Only modified components are written back to system on Apply

**Lazy Tab Loading:**
Three tabs (Date/Time, Hardware Clock, Network Time) load content only when first accessed via `loadTab()` to improve startup performance.

## Translation System

Translations are in `translations/` directory as Qt `.ts` files. The build system automatically compiles them to `.qm` files and embeds them in a resource file.

To add a new translation:
1. Add `mx-datetime_XX.ts` file in `translations/` directory
2. Touch `CMakeLists.txt` to trigger CMake reconfiguration (GLOB pattern used)
3. Rebuild project

Translation loading in `main.cpp` searches `/usr/share/mx-datetime/locale` for compiled translations.

## Code Style

- **C++ Standard:** C++20 (CMAKE_CXX_STANDARD=20)
- **Qt Version:** Qt6 (minimum 6.4, deprecations disabled up to 6.4)
- **String Literals:** Use Qt string literals `u"text"_s` (via `using namespace Qt::StringLiterals`)
- **Headers:** Apache 2.0 license header required in all source files
- **Qt Deprecated APIs:** Disabled via `QT_DISABLE_DEPRECATED_UP_TO=0x060400`
- **Compiler Warnings:** `-Wall -Wextra -Wpedantic` enabled for all builds
- **Optimization:** `-O2` for all build types, LTO enabled for release builds

## Version Management

Version comes from `debian/changelog` via `dpkg-parsechangelog` command during build. The version is passed to the binary as a compile-time definition (`VERSION`).

## Key System Interactions

- `/etc/localtime` - System timezone symlink
- `/etc/timezone` - Timezone name file (must stay in sync with `/etc/localtime`)
- `/usr/share/zoneinfo/` - Timezone database
- NTP configuration varies by init system:
  - SystemD: Uses `timedatectl` commands
  - OpenRC: Direct systemd-timesyncd or ntpd service control
  - SystemV: Service scripts via `service` command
- Hardware clock operations use `hwclock` command with appropriate flags

## Packaging

The project supports multiple packaging formats:

**Debian/Ubuntu:**
- Uses standard debian packaging in `debian/` directory
- Version extracted from `debian/changelog` via `dpkg-parsechangelog`

**Arch Linux:**
- PKGBUILD file in repository root
- Build with `./build.sh --arch`
- Uses version from `debian/changelog` (unified versioning)
- Outputs package to `build/*.pkg.tar.zst`
- Includes polkit policy, helper script, translations, icons, and desktop file

## Debugging

- Application outputs debug messages to stderr via `qDebug()`
- All command executions are logged with their arguments and exit codes
- Init system detection is logged on startup
- Run with `QT_LOGGING_RULES="*.debug=true"` environment variable for verbose Qt logging
