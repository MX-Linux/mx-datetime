Format: 3.0 (native)
Source: mx-datetime
Binary: mx-datetime
Architecture: any
Version: 26.07
Maintainer: Adrian <adrian@mxlinux.org>
Homepage: https://github.com/MX-Linux/mx-datetime
Standards-Version: 4.5.1
Vcs-Git: git://github.com/MX-Linux/mx-datetime
Build-Depends: debhelper-compat (= 13), cmake (>= 3.25), ninja-build (>= 1.10), qt6-base-dev, qt6-base-dev-tools, qt6-tools-dev, qt6-tools-dev-tools
Package-List:
 mx-datetime deb admin optional arch=any
Checksums-Sha1:
 a42f4e4037ab4b0cf715ab0fe213ca4c23226794 5486356 mx-datetime_26.07.tar.xz
Checksums-Sha256:
 1f84eb25ef4140bbe783322510bd267feca7e972124a1ea48c265e048f18ba08 5486356 mx-datetime_26.07.tar.xz
Files:
 540e8fb4c8b39adc4cf208879b214f84 5486356 mx-datetime_26.07.tar.xz
