<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="hr">
<context>
    <name>MXDateTime</name>
    <message>
        <location filename="../datetime.ui" line="20"/>
        <location filename="../datetime.cpp" line="604"/>
        <source>MX Date &amp; Time</source>
        <translation>MX datum &amp; vrijeme</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="26"/>
        <source>Close</source>
        <translation>Zatvori</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="40"/>
        <source>Help</source>
        <translation>Pomoć</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="73"/>
        <source>Apply</source>
        <translation>Primjeni</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="100"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="124"/>
        <source>Date &amp;&amp; Time</source>
        <translation>Datum &amp; vrijeme</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="192"/>
        <source>H:mm:ss</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="278"/>
        <location filename="../datetime.cpp" line="296"/>
        <location filename="../datetime.cpp" line="303"/>
        <source>Hardware Clock</source>
        <translation>Sat sklopovlja</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="284"/>
        <source>Hardware Clock tools</source>
        <translation>Alati sata sklopovlja</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="290"/>
        <source>Obtain information from the Hardware Clock and present it in the box below.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="293"/>
        <source>Read the Hardware Clock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="303"/>
        <source>Apply systematic drift corrections to the Hardware Clock.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="306"/>
        <source>Drift Adjust</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="329"/>
        <source>Time transfer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="335"/>
        <source>Immediately set the System Clock to match the current time registered by the Hardware Clock.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="338"/>
        <source>Hardware Clock to System Clock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="348"/>
        <source>Immediately set the Hardware Clock to match the current time registered by the System Clock.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="351"/>
        <source>System Clock to Hardware Clock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="361"/>
        <source>Update the drift factor for the Hardware Clock when it is being set.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="364"/>
        <source>Update the drift</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="374"/>
        <source>Time zone for the Hardware Clock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="380"/>
        <source>Local time</source>
        <translation>Lokalno vrijeme</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="383"/>
        <source>Local</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="390"/>
        <source>Universally Coordinated Time (or Greenwich Meridian Time)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.ui" line="393"/>
        <source>UTC</source>
        <translation>UTC</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="433"/>
        <source>Network Time</source>
        <translation>Mrežno vrijeme</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="439"/>
        <source>Move the selected item down</source>
        <translation>Pomaknite odabranu stavku dolje</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="450"/>
        <source>Move the selected item up</source>
        <translation>Pomaknite odabranu stavku gore</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="461"/>
        <source>Remove the current item from the list</source>
        <translation>Uklonite trenutnu stavku sa liste</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="472"/>
        <source>Add an item to the list</source>
        <translation>Dodajte stavku na listu</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="498"/>
        <source>Automatically update the System Clock with NTP servers:</source>
        <translation>Automatski ažurirajte sat sustava sa NTP poslužiteljima:</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="505"/>
        <source>Immediately update the system clock with NTP servers.</source>
        <translation>Odmah ažurirajte sat sustava sa NTP poslužiteljima.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="508"/>
        <source>Update Now</source>
        <translation>Ažurirajte sada</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="520"/>
        <source>List of NTP servers to use.</source>
        <translation>Lista NTP poslužitelja za uporabu.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="536"/>
        <source>Type</source>
        <translation>Vrsta</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="541"/>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="546"/>
        <source>Options</source>
        <translation>Opcije</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="270"/>
        <source>Reading...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="284"/>
        <source>Adjusting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="296"/>
        <location filename="../datetime.cpp" line="303"/>
        <source>System Clock</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="309"/>
        <source>The %1 time was transferred to the %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="312"/>
        <source>The %1 time could not be transferred to the %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="352"/>
        <source>Updating...</source>
        <translation>Ažuriram...</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="365"/>
        <source>The system clock was updated successfully.</source>
        <translation>Sat sustava uspješno je ažuriran.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="367"/>
        <source>The system clock could not be updated.</source>
        <translation>Sat sustava ne može se ažurirati.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="369"/>
        <source>None of the NTP servers on the list are currently enabled.</source>
        <translation>Nijedan od NTP poslužitelja sa liste trenutno nije omogućen.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="603"/>
        <source>About MX Date &amp; Time</source>
        <translation>O MX datumu i vremenu</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="604"/>
        <source>Version: </source>
        <translation>Inačica:</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="605"/>
        <source>GUI program for setting the time and date in MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="607"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Autorska prava (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="608"/>
        <location filename="../datetime.cpp" line="622"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="609"/>
        <source>Changelog</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../datetime.cpp" line="610"/>
        <source>Cancel</source>
        <translation>Otkaži</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="636"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvori</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="654"/>
        <source>MX Date &amp; Time Help</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>