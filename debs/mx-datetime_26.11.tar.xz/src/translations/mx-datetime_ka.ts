<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ka">
<context>
    <name>MXDateTime</name>
    <message>
        <location filename="../datetime.ui" line="20"/>
        <location filename="../datetime.cpp" line="604"/>
        <source>MX Date &amp; Time</source>
        <translation>MX Date &amp; Time</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="26"/>
        <source>Close</source>
        <translation>დახურვა</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="40"/>
        <source>Help</source>
        <translation>დახმარება</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="73"/>
        <source>Apply</source>
        <translation>გადატარება</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="100"/>
        <source>About...</source>
        <translation>შესახებ...</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="124"/>
        <source>Date &amp;&amp; Time</source>
        <translation>თარიღი &amp; დრო</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="192"/>
        <source>H:mm:ss</source>
        <translation>ს:წთ:წმ</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="278"/>
        <location filename="../datetime.cpp" line="296"/>
        <location filename="../datetime.cpp" line="303"/>
        <source>Hardware Clock</source>
        <translation>აპარატურული საათი</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="284"/>
        <source>Hardware Clock tools</source>
        <translation>აპარატურული საათის პროგრამები</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="290"/>
        <source>Obtain information from the Hardware Clock and present it in the box below.</source>
        <translation>ინფორმაციის მიღება აპარატურული საათიდან და მისი ქვედა ველში ჩვენება.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="293"/>
        <source>Read the Hardware Clock</source>
        <translation>აპარატურული საათის წაკითხვა</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="303"/>
        <source>Apply systematic drift corrections to the Hardware Clock.</source>
        <translation>სისტემატიკური აცდენის კორექციების გადატარება აპარატურულ საათზე.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="306"/>
        <source>Drift Adjust</source>
        <translation>აცდენის გასწორება</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="329"/>
        <source>Time transfer</source>
        <translation>დროის გადაცემა</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="335"/>
        <source>Immediately set the System Clock to match the current time registered by the Hardware Clock.</source>
        <translation>სისტემური საათის დაუყოვნებლივ შეცვლა, რომ ის აპარატურულ საათში არსებულ დროს ემთხვეოდეს.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="338"/>
        <source>Hardware Clock to System Clock</source>
        <translation>აპარატურული საათიდან სისტემურ საათზე</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="348"/>
        <source>Immediately set the Hardware Clock to match the current time registered by the System Clock.</source>
        <translation>აპარატურული საათის დაუყოვნებლივ შეცვლა, რომ ის სისტემურ საათში არსებულ დროს ემთხვეოდეს.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="351"/>
        <source>System Clock to Hardware Clock</source>
        <translation>სისტემური საათიდან აპარატურულ საათზე</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="361"/>
        <source>Update the drift factor for the Hardware Clock when it is being set.</source>
        <translation>აცდენის ფაქტორის განახლება აპარატურული საათისთვის, როცა მისი დაყენება ხდება.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="364"/>
        <source>Update the drift</source>
        <translation>აცდენის განახლება</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="374"/>
        <source>Time zone for the Hardware Clock</source>
        <translation>დროის სარტყელი აპარატურული საათისთვის</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="380"/>
        <source>Local time</source>
        <translation>ლოკალური დრო</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="383"/>
        <source>Local</source>
        <translation>ლოკალური</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="390"/>
        <source>Universally Coordinated Time (or Greenwich Meridian Time)</source>
        <translation>უნივერსალურად კოორდინირებული დრო (ან გრინვიჩის მერიდიანის დრო)</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="393"/>
        <source>UTC</source>
        <translation>UTC</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="433"/>
        <source>Network Time</source>
        <translation>ქსელის დრო</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="439"/>
        <source>Move the selected item down</source>
        <translation>მონიშნული ელემენტების აბლა ჩამოტანა</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="450"/>
        <source>Move the selected item up</source>
        <translation>მონიშნული ელემენტის ატანა</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="461"/>
        <source>Remove the current item from the list</source>
        <translation>მონიშნული ელემენტის წაშლა სიიდან</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="472"/>
        <source>Add an item to the list</source>
        <translation>ელემენტის ჩამატება სიაში</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="498"/>
        <source>Automatically update the System Clock with NTP servers:</source>
        <translation>სისტემური საათის ავტომატური განახლება NTP სერვერებიდან:</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="505"/>
        <source>Immediately update the system clock with NTP servers.</source>
        <translation>სისტემური საათის დაუყოვნებლივი განახლება NTP სერვერებიდან.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="508"/>
        <source>Update Now</source>
        <translation>ახლა განახლება</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="520"/>
        <source>List of NTP servers to use.</source>
        <translation>გამოსაყენებელი NTP სერვერების სია.</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="536"/>
        <source>Type</source>
        <translation>ტიპი</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="541"/>
        <source>Address</source>
        <translation>მისამართი</translation>
    </message>
    <message>
        <location filename="../datetime.ui" line="546"/>
        <source>Options</source>
        <translation>მორგება</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="270"/>
        <source>Reading...</source>
        <translation>მიმდინარეობს წაკითხვა...</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="284"/>
        <source>Adjusting...</source>
        <translation>გასწორება...</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="296"/>
        <location filename="../datetime.cpp" line="303"/>
        <source>System Clock</source>
        <translation>სისტემური საათი</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="309"/>
        <source>The %1 time was transferred to the %2.</source>
        <translation>%1-ის დრო გადატანილია %2-ზე.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="312"/>
        <source>The %1 time could not be transferred to the %2.</source>
        <translation>%1-ის დროის გადატანა %2-ზე შეუძლებელია.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="352"/>
        <source>Updating...</source>
        <translation>განახლება...</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="365"/>
        <source>The system clock was updated successfully.</source>
        <translation>სისტემური საათი წარმატებით განახლდა.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="367"/>
        <source>The system clock could not be updated.</source>
        <translation>სისტემურის საათის განახლება შეუძლებელია.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="369"/>
        <source>None of the NTP servers on the list are currently enabled.</source>
        <translation>NTP სერვერების სიიდან ჩართული არცერთია.</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="603"/>
        <source>About MX Date &amp; Time</source>
        <translation>MX Date &amp; Time-ის შესახებ</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="604"/>
        <source>Version: </source>
        <translation>ვერსია: </translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="605"/>
        <source>GUI program for setting the time and date in MX Linux</source>
        <translation>გრაფიკული პროგრამა MX Linux-ში დროისა და თარიღის დასაყენებლად</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="607"/>
        <source>Copyright (c) MX Linux</source>
        <translation>(c) MX Linux საავტორო ფულებები დაცულია</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="608"/>
        <location filename="../datetime.cpp" line="622"/>
        <source>License</source>
        <translation>ლიცენზია</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="609"/>
        <source>Changelog</source>
        <translation>ცვლილებების ჟურნალი</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="610"/>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="636"/>
        <source>&amp;Close</source>
        <translation>&amp;დახურვა</translation>
    </message>
    <message>
        <location filename="../datetime.cpp" line="654"/>
        <source>MX Date &amp; Time Help</source>
        <translation>MX Date &amp; Time-ის დახმარება</translation>
    </message>
</context>
</TS>